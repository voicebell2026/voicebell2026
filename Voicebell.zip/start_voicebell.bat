@echo off
title VoiceBell Server

echo.
echo  ==========================================
echo  VoiceBell Server Starting...
echo  ==========================================
echo.
echo  [NOTICE]
echo  Please place this file on your Desktop.
echo  The server folder must be in the same
echo  location as this file.
echo.
echo  [WARNING]
echo  If connection fails, right-click and
echo  select "Run as administrator".
echo  ==========================================
echo.

set SERVER_PATH=%~dp0server\server.exe

if not exist "%SERVER_PATH%" (
    echo  [ERROR] server.exe not found.
    echo  Please make sure the server folder is
    echo  in the same location as this file.
    echo.
    pause
    exit /b 1
)

echo  Waiting for server to start...
timeout /t 2 /nobreak > nul

echo  Opening browser...
start "" "https://localhost:8444?role=counter"

echo.
echo  VoiceBell is running!
echo  Counter PC   : https://localhost:8444?role=counter
echo  Other devices: See IP address shown in the server window.
echo.
echo  Press Ctrl+C or close this window to stop.
echo.

"%SERVER_PATH%"

echo.
echo  Server has stopped. Press any key to close.
pause > nul
